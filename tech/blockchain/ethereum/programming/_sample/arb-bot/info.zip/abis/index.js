const kyber = require('./kyber.json');

module.exports = {
  kyber
};
